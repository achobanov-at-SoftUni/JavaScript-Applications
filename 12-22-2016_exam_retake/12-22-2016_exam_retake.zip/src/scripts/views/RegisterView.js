import React, {Component} from "react";

import RegisterForm from "../components/RegisterForm";

export default class RegisterView extends Component {
    render() {
        return (
            <RegisterForm/>
        );
    }
}
 
