import React, {Component} from "react";

import ShopTable from "../components/ShopTable";

export default class ShopView extends Component {
    render() {
        return (
            <ShopTable/>
        )
    }
}


 
