import React, {Component} from "react";

import CartTable from "../components/CartTable";

export default class CartView extends Component {
    render() {
        return (
            <CartTable/>
        )
    }
}
 
