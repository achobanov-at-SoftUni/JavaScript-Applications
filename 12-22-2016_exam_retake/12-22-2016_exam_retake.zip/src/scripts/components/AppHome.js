import React, {Component} from "react";

export default class AppHome extends Component{
    render() {
        return (
            <section id="viewAppHome">
                <h1>Welcome</h1>
                Welcome to our shopping system.
            </section>
        )
    }
}


 
