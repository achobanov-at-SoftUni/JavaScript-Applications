export default class Utils {

    static formatPrice(price) {
        return Number(price).toFixed(2);
    }
}
 
